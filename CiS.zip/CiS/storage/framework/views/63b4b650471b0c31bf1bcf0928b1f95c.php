

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('warehouse.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="cust_name">Warehouse Name</label>
            <input type="text" class="form-control" name="warehouse_name" aria-describedby="nameHelp"
                placeholder="Enter Your Warehouse Name">
            <small id="nameHelp" class="form-text text-muted">Please enter your warehouse name</small>
        </div>

        <div class="form-group">
            <label for="cust_name">Warehouse Address</label>
            <input type="text" class="form-control" name="warehouse_address" aria-describedby="nameHelp"
                placeholder="Enter Your Warehouse Address">
            <small id="nameHelp" class="form-text text-muted">Please enter your warehouse address</small>
        </div>
        <a class="btn btn-info" href="<?php echo e(url()->previous()); ?>">Cancel</a>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS\resources\views/warehouse/create.blade.php ENDPATH**/ ?>