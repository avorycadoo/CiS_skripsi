;

<?php $__env->startSection('content'); ?> 
<form method="POST" action="<?php echo e(route('employe.update', $data->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="name">Employee Name</label>
        <input type="text" class="form-control" name="name" aria-describedby="typeHelp" placeholder="Enter customer's name" value="<?php echo e($data -> name); ?>">

        <label for="address">Employee Phone Number</label>
        <input type="text" class="form-control" name="phone_number" aria-describedby="typeHelp" placeholder="Enter customer's phone number" value="<?php echo e($data -> phone_number); ?>">

        <label for="address">Employee Address</label>
        <input type="text" class="form-control" name="address" aria-describedby="typeHelp" placeholder="Enter customer's address" value="<?php echo e($data -> address); ?>">

    </div>
    <a class ="btn btn-info" href="<?php echo e(url()->previous()); ?>"> Cancel </a>
    <button type="submit" class="btn btn-primary">Submit</button>

    
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS\resources\views/employee/edit.blade.php ENDPATH**/ ?>