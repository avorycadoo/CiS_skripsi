

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center mb-4">Product Catalog</h2>
                <a class="btn btn-warning btn-sm" style="background-color: #000000; color: white;"
                    href="<?php echo e(route('product.create')); ?>"> + Product</a><br>
                <div class="row">
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="card shadow-sm h-100">
                                <!-- Product Image -->
                                <div class="card-img-top text-center">
                                    <?php if($d->productImage): ?>
                                        <img src="<?php echo e(asset('/images/' . $d->productImage->name)); ?>"
                                            class="img-fluid img-thumbnail" alt="<?php echo e($d->name); ?>"
                                            style="max-height: 200px; object-fit: cover;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/images/no-image.png')); ?>" class="img-fluid img-thumbnail"
                                            alt="No image available" style="max-height: 200px; object-fit: cover;">
                                    <?php endif; ?>
                                </div>
                                <!-- Product Details -->
                                <div class="card-body">
                                    <h5 class="card-title text-center"><?php echo e($d->name); ?></h5>
                                    <p class="card-text text-muted text-center"><?php echo e($d->desc); ?></p>
                                    <p class="card-text text-center">
                                        <strong>Price:</strong> Rp <?php echo e(number_format($d->price, 0, ',', '.')); ?>

                                    </p>
                                    <p class="card-text text-center">
                                        <strong>Cost:</strong> Rp <?php echo e(number_format($d->cost, 0, ',', '.')); ?>

                                    </p>
                                    <p class="text-center text-muted">
                                        <small>Created: <?php echo e($d->created_at); ?></small><br>
                                        <small>Updated: <?php echo e($d->updated_at); ?></small>
                                    </p>
                                    <!-- Action Buttons -->
                                    <div class="text-center">
                                        <a class="btn btn-warning btn-sm" style="background-color: #000000; color: white;"
                                            href="<?php echo e(route('product.edit', $d->id)); ?>">Edit</a>
                                        <a class="btn btn-info btn-sm" style="background-color: #000000; color: white;"
                                            href="<?php echo e(url('product/uploadPhoto/' . $d->id)); ?>">Upload Photo</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\kerja\tajoki\laravel\pos_laravel\CiS\resources\views/product/index.blade.php ENDPATH**/ ?>