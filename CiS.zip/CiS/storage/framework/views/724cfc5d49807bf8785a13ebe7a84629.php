

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Transaction Details - <?php echo e($purchase->noNota); ?></h2>

        <div class="card shadow-sm">
            <div class="card-body">
                <h5><strong>Supplier:</strong> <?php echo e($purchase->supplier->company_name); ?></h5>
                <h5><strong>Total Price:</strong> Rp <?php echo e(number_format($purchase->total_price, 0, ',', '.')); ?></h5>
                <h5><strong>Payment Method:</strong> <?php echo e($purchase->paymentMethod->name); ?></h5>
                <h5><strong>Purchase Date:</strong> <?php echo e($purchase->purchase_date); ?></h5>
                <h5><strong>Receive Date:</strong> <?php echo e($purchase->receive_date); ?></h5>
                <h5><strong>Shipping Cost:</strong> Rp <?php echo e(number_format($purchase->shipping_cost, 0, ',', '.')); ?></h5>
                <h5><strong>Created At:</strong> <?php echo e($purchase->created_at); ?></h5>
                <h5><strong>Updated At:</strong> <?php echo e($purchase->updated_at); ?></h5>

                <h5 class="mt-4">Products:</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Subtotal Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($purchase->purchaseDetails->isNotEmpty()): ?>
                            <?php $__currentLoopData = $purchase->purchaseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($detail->product->name); ?></td>
                                    <td><?php echo e($detail->quantity); ?></td>
                                    <td>Rp <?php echo e(number_format($detail->subtotal_price, 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-center">No products found for this purchase.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="text-center mt-4">
                    <a href="<?php echo e(route('purchase.index')); ?>" class="btn btn-info">Back to Purchases</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS\resources\views/purchase/detail.blade.php ENDPATH**/ ?>