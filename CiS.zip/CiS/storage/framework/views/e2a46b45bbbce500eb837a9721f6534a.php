

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center mb-4">Transactions Purchase</h2>
                <div class="d-flex justify-content-end mb-3">
                    <a href="<?php echo e(route('purchase.create')); ?>" class="btn btn-info"
                        style="background-color: #000000; color: white; border: none; transition: background-color 0.3s;">
                        + New Purchase
                    </a>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="card shadow-sm h-100">
                                <!-- Purchase Details -->
                                <div class="card-body">
                                    <h5 class="card-title text-center"><?php echo e($d->noNota); ?></h5>
                                    <p class="card-text text-center">
                                        <strong>Total Price:</strong> Rp <?php echo e(number_format($d->total_price, 0, ',', '.')); ?>

                                    </p>
                                    <p class="card-text text-center">
                                        <strong>Payment Method:</strong> <?php echo e($d->paymentMethod->name ?? 'N/A'); ?>

                                    </p>
                                    <p class="card-text text-center">
                                        <strong>Supplier:</strong> <?php echo e($d->supplier->company_name ?? 'N/A'); ?>

                                    </p>
                                    <p class="text-center text-muted">
                                        <small>Purchase Date: <?php echo e($d->purchase_date); ?></small><br>
                                        <small>Created: <?php echo e($d->created_at); ?></small><br>
                                        <small>Updated: <?php echo e($d->updated_at); ?></small>
                                    </p>
                                    <!-- Action Buttons -->
                                    <div class="text-center">
                                        <a class="btn btn-warning btn-sm"
                                            style="background-color: rgb(0, 0, 0); color: white; margin-right: 5px;"
                                            href="<?php echo e(route('purchase.detail', $d->id)); ?>">Detail</a>
                                        <form method="POST" action="<?php echo e(route('purchase.destroy', $d->id)); ?>"
                                            style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="submit" value="Delete" class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you sure to delete <?php echo e($d->id); ?> - <?php echo e($d->noNota); ?>?');">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS\resources\views/purchase/index.blade.php ENDPATH**/ ?>