

<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <form action="<?php echo e(route('sales.updateConfiguration')); ?>" method="POST"> <!-- Updated route -->
            <?php echo csrf_field(); ?>
            <h2>Discount Configuration</h2>
            <div class="form-group">
                <label for="discounts">Select Discounts:</label><br>
                <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="discounts[]" value="<?php echo e($discount->id); ?>"
                            id="discount<?php echo e($discount->id); ?>"
                            <?php echo e(in_array($discount->id, old('discounts', [])) || $discount->statusActive == 1 ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="discount<?php echo e($discount->id); ?>">
                            <?php echo e($discount->name); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>




            

            
            <h2>Shipping Configuration</h2>
            <div class="form-group">
                <label for="shippings">Select Shippings:</label><br>
                <?php $__currentLoopData = $shippings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="shippings[]" value="<?php echo e($shipping->id); ?>"
                            id="shipping<?php echo e($shipping->id); ?>" <?php echo e($shipping->statusActive ? 'checked' : ''); ?>

                            <?php echo e($shipping->types === 'mandatory' ? 'checked' : ''); ?> 
                            <?php echo e($shipping->types === 'mandatory' ? 'disabled' : ''); ?>>
                        <label class="form-check-label" for="shipping<?php echo e($shipping->id); ?>">
                            <?php echo e($shipping->name); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <h2>Payment Methods Configuration</h2>
            <div class="form-group">
                <label for="payments">Select Payment Methods:</label><br>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="payments[]" value="<?php echo e($payment->id); ?>"
                            id="payment<?php echo e($payment->id); ?>" <?php echo e($payment->statusActive ? 'checked' : ''); ?>

                            <?php echo e($payment->types === 'mandatory' ? 'checked' : ''); ?>

                            <?php echo e($payment->types === 'mandatory' ? 'disabled' : ''); ?>>
                        <label class="form-check-label" for="payment<?php echo e($payment->id); ?>">
                            <?php echo e($payment->name); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS\resources\views/sales/konfigurasi.blade.php ENDPATH**/ ?>