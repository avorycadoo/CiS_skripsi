

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <h3 class="page-title">Upload your image product <?php echo e($product_image->name); ?></h3>
    <div class="container">
        <form method="POST" enctype="multipart/form-data" action="<?php echo e(url('image/store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleInputType">Choose Image</label>
                <input type="file" class="form-control" name="file_photo" />
                <input type="hidden" name='product_image_id' value="<?php echo e($image->id); ?>" />
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS\resources\views/image/create.blade.php ENDPATH**/ ?>