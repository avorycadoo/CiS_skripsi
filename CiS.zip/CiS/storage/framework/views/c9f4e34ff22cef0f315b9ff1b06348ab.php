

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('product.store')); ?>">
        <?php echo csrf_field(); ?>

        <fieldset class="border p-3 mb-4">
            <legend class="w-auto">Product Information</legend>

            <div class="form-group">
                <label for="product_name">Product Name</label>
                <input type="text" class="form-control" name="product_name" placeholder="Enter Your Product" required>
                <small class="form-text text-muted">Please enter your product name</small>
            </div>

            <div class="form-group">
                <label for="product_desc">Description</label>
                <input type="text" class="form-control" name="product_desc" placeholder="Enter Product Description"
                    required>
                <small class="form-text text-muted">Please enter your product description</small>
            </div>

            <div class="form-group">
                <label for="product_price">Price</label>
                <input type="number" class="form-control" name="product_price" placeholder="Enter Product Price" required>
                <small class="form-text text-muted">Please enter your product price</small>
            </div>

            <div class="form-group">
                <label for="product_cost">Cost</label>
                <input type="number" class="form-control" name="product_cost" placeholder="Enter Product Cost" required>
                <small class="form-text text-muted">Please enter your product cost</small>
            </div>

            <div class="form-group">
                <label for="product_stock">Stock</label>
                <input type="number" class="form-control" name="product_stock" placeholder="Enter Product Stock" required>
                <small class="form-text text-muted">Please enter your product stock</small>
            </div>

            <div class="form-group">
                <label for="product_minstock">Minimum Stock</label>
                <input type="number" class="form-control" name="product_minstock" min="5"
                    placeholder="Enter Minimum Stock" required>
                <small class="form-text text-muted">Minimum stock cannot be less than 5.</small>
            </div>

            <div class="form-group">
                <label for="product_maksretur">Maximum Return</label>
                <input type="number" class="form-control" name="product_maksretur" max="5"
                    placeholder="Enter Maximum Return" required>
                <small class="form-text text-muted">Maximum return cannot be more than 5.</small>
            </div>

        </fieldset>

        <fieldset class="border p-3 mb-4">
            <legend class="w-auto">Additional Information</legend>

            <div class="form-group">
                <label for="product_image_id">Select Image</label>
                <select class="form-control" name="product_image_id">
                    <option value="" selected>Select Your Image</option>
                    <option value="">None</option> <!-- Option to unselect -->
                    <?php $__currentLoopData = $product_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($img->id); ?>"><?php echo e($img->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-text text-muted">If there is no suitable product photo then select "None" or leave
                    blank!</small>
            </div>


            <div class="form-group">
                <label for="product_category_id">Select Category</label>
                <select class="form-control" name="product_category_id" required>
                    <option value="" disabled selected>Select Your Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-text text-muted">Select a category for your product.</small>
            </div>

            <div class="form-group">
                <label for="product_supplier_id">Select Supplier</label>
                <select class="form-control" name="product_supplier_id" required>
                    <option value="" disabled selected>Select Your Supplier</option>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->company_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-text text-muted">Select a supplier for your product.</small>
            </div>

            <div class="form-group">
                <label for="product_warehouse_id">Select Warehouse</label>
                <select class="form-control" name="product_warehouse_id" required>
                    <option value="" disabled selected>Select Your Warehouse</option>
                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-text text-muted">Select a warehouse for your product.</small>
            </div>
        </fieldset>

        <div class="d-flex justify-content-between">
            <a class="btn btn-info" href="<?php echo e(url()->previous()); ?>" >Cancel</a>
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\kerja\tajoki\laravel\pos_laravel\CiS\resources\views/product/create.blade.php ENDPATH**/ ?>