

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <form action="<?php echo e(route('sales.updateConfiguration')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            
            <div class="card mb-4">
                <div class="card-body">
                    <h2>Discount Configuration</h2>
                    <label for="discounts">Select Discounts:</label><br>
                    <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-center mb-2"> 
                            <input class="form-check-input me-2" type="checkbox" name="discounts[]" value="<?php echo e($discount->id); ?>"
                                id="discount_<?php echo e($discount->id); ?>" <?php echo e($discount->statusActive ? 'checked' : ''); ?>>
                            <label class="form-check-label me-2" for="discount_<?php echo e($discount->id); ?>">
                                <?php echo e($discount->name); ?>

                            </label>
                            <input type="number" name="discount_values[<?php echo e($discount->id); ?>]" class="form-control w-25"
                                value="<?php echo e($discount->value); ?>">
                        </div>
                        <div>
                            <small class="text-muted"><?php echo e($discount->desc); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>


            
            <div class="card mb-4">
                <div class="card-body">
                    <h2>Shipping Configuration</h2>
                    <label for="shippings">Select Shippings:</label><br>
                    <?php $__currentLoopData = $shippings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-center mb-2">
                            <input class="form-check-input me-2" type="checkbox" name="shippings[]"
                                value="<?php echo e($shipping->id); ?>" id="shipping_<?php echo e($shipping->id); ?>"
                                <?php echo e($shipping->statusActive ? 'checked' : ''); ?>>
                            <label class="form-check-label me-2" for="shipping_<?php echo e($shipping->id); ?>">
                                <?php echo e($shipping->name); ?>

                            </label>
                            <input type="number" name="shipping_values[<?php echo e($shipping->id); ?>]" class="form-control w-25"
                                value="<?php echo e($shipping->value); ?>">
                        </div>
                        <div>
                            <small class="text-muted"><?php echo e($shipping->desc); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <div class="card mb-4">
                <div class="card-body">
                    <h2>Payment Methods Configuration</h2>
                    <label for="payments">Select Payment Methods:</label><br>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-center mb-2">
                            <input class="form-check-input me-2" type="checkbox" name="payments[]"
                                value="<?php echo e($payment->id); ?>" id="payment_<?php echo e($payment->id); ?>"
                                <?php echo e($payment->statusActive ? 'checked' : ''); ?>>
                            <label class="form-check-label me-2" for="payment_<?php echo e($payment->id); ?>">
                                <?php echo e($payment->name); ?>

                            </label>
                        </div>
                        <div>
                            <small class="text-muted"><?php echo e($payment->desc); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>


            
            <div class="card mb-4">
                <div class="card-body">
                    <h2>COGS Sales Configuration</h2>
                    <label for="cogs">Select COGS:</label><br>
                    <?php $__currentLoopData = $cogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cogs_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-center mb-2">
                            <input class="form-check-input me-2" type="checkbox" name="cogs[]"
                                value="<?php echo e($cogs_method->id); ?>" id="cogs_<?php echo e($cogs_method->id); ?>"
                                <?php echo e($cogs_method->statusActive ? 'checked' : ''); ?>>
                            <label class="form-check-label me-2" for="cogs_<?php echo e($cogs_method->id); ?>">
                                <?php echo e($cogs_method->name); ?>

                            </label>
                        </div>
                        <div>
                            <small class="text-muted"><?php echo e($cogs_method->desc); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-4">Save Configurations</button>
        </form>
        <br><br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS_skripsi\CiS\CiS\resources\views/sales/konfigurasi.blade.php ENDPATH**/ ?>