

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Product List</h1>
        
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Stock</th>
                    <th>In Order</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->stock); ?></td>
                        <td><?php echo e($product->in_order_penjualan); ?></td>
                        <td>
                            <form action="<?php echo e(route('products.create-shipping-purchase', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <div class="input-group">
                                    <input type="number" name="quantity_shipped" class="form-control" min="1"
                                        required>
                                    <button type="submit" class="btn btn-primary">Ship</button>
                                </div>
                            </form>
                            <form action="<?php echo e(route('products.confirm-receipt-purchase', $product)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-success mt-2"
                                    <?php echo e($product->in_order_penjualan == 0 ? 'disabled' : ''); ?>>Confirm Receipt</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS_skripsi\CiS\CiS\resources\views/purchase/shipping.blade.php ENDPATH**/ ?>