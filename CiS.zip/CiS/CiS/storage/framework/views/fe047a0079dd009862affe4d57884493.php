

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <h3 class="page-title">Upload Image for Product: <?php echo e($product->name); ?></h3>
    <div class="container">
        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data" action="<?php echo e(url('product/simpanPhoto')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="file_photo">Choose Image</label>
                <input type="file" class="form-control" name="file_photo" required />
                
                <!-- Hidden input for product ID -->
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS_skripsi\CiS\CiS\resources\views/image/formUploadPhoto.blade.php ENDPATH**/ ?>