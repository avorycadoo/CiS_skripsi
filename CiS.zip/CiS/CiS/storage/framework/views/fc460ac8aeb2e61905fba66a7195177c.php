;

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('product.update', $data->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="name">Product Name</label>
            <input type="text" class="form-control" name="name" aria-describedby="typeHelp"
                placeholder="Enter product name" value="<?php echo e($data->name); ?>">
        </div>

        <div class="form-group">
            <label for="name">Product Description</label>
            <input type="text" class="form-control" name="desc" aria-describedby="typeHelp"
                placeholder="Enter product description" value="<?php echo e($data->desc); ?>">
        </div>

        <div class="form-group">
            <label for="name">Product Price</label>
            <input type="text" class="form-control" name="price" aria-describedby="typeHelp"
                placeholder="Enter product price" value="<?php echo e($data->price); ?>">
        </div>

        <div class="form-group">
            <label for="name">Product Cost</label>
            <input type="text" class="form-control" name="cost" aria-describedby="typeHelp"
                placeholder="Enter product cost" value="<?php echo e($data->cost); ?>">
        </div>

        <div class="form-group">
            <label for="name">Minimum Stock</label>
            <input type="text" class="form-control" name="minimum_stock" aria-describedby="typeHelp"
                placeholder="Enter your minimum stock" value="<?php echo e($data->minimum_stock); ?>">
        </div>

        <div class="form-group">
            <label for="name">Maksimum Retur</label>
            <input type="text" class="form-control" name="maksimum_retur" aria-describedby="typeHelp"
                placeholder="Enter your maksimum retur" value="<?php echo e($data->maksimum_retur); ?>">
        </div>

        <a class ="btn btn-info" href="<?php echo e(url()->previous()); ?>"> Cancel </a>
        <button type="submit" class="btn btn-primary">Submit</button>


    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS_skripsi\CiS\CiS\resources\views/product/edit.blade.php ENDPATH**/ ?>