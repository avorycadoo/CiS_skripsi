<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">



    <title>Electronics Configurations App</title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('conquer/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('conquer/css/sb-admin-2.min.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('javascript'); ?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul style="background: rgb(70, 5, 5); padding-top: 20px;"
            class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Electronics Configurations App</div>
            </a>

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('pos.index')); ?>">
                    <i class="fas fa-fw fa-cart-plus"></i>
                    <span>POS Cashier</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#salesModuleMenu"
                    aria-expanded="false" aria-controls="salesModuleMenu">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Modul Penjualan</span>
                </a>
                <div id="salesModuleMenu" class="collapse">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="penjualan">
                            <i class="fas fa-fw fa-chart-line"></i>
                            <span>Nota Penjualan</span>
                        </a>
                        <a class="collapse-item" href="sales">
                            <i class="fas fa-fw fa-receipt"></i>
                            <span>Transaction Sales</span>
                        </a>

                        <a class="collapse-item" href="salesKonfigurasi">
                            <i class="fas fa-fw fa-receipt"></i>
                            <span>Sales Configurations</span>
                        </a>

                        <a class="collapse-item" href="salesRetur">
                            <i class="fas fa-fw fa-receipt"></i>
                            <span>Sales Return</span>
                        </a>

                    </div>
                </div>
            </li>

            <li class="nav-item active">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#purchaseModuleMenu"
                    aria-expanded="false" aria-controls="purchaseModuleMenu">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Modul Pembelian</span>
                </a>

                <div id="purchaseModuleMenu" class="collapse">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="purchase">
                            <i class="fas fa-fw fa-receipt"></i>
                            <span>Transaction Purchase</span>
                        </a>

                        <a class="collapse-item" href="purchaseKonfigurasi">
                            <i class="fas fa-fw fa-receipt"></i>
                            <span>Purchase Configuration</span>
                        </a>

                        <a class="collapse-item" href="purchaseRetur">
                            <i class="fas fa-fw fa-receipt"></i>
                            <span>Purchase Return</span>
                        </a>

                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#inventoriesMenu"
                    aria-expanded="false" aria-controls="inventoriesMenu">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Modul Inventory</span>
                </a>
                <div id="inventoriesMenu" class="collapse">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="product">
                            <i class="fas fa-fw fa-receipt"></i>
                            <span>Product</span>
                        </a>
                        <a class="collapse-item" href="<?php echo e(route('categories.index')); ?>">
                            <i class="fas fa-fw fa-user"></i>
                            <span>Category</span>
                        </a>
                        <a class="collapse-item" href="<?php echo e(route('warehouse.index')); ?>">
                            <i class="fas fa-fw fa-user"></i>
                            <span>Warehouse</span>
                        </a>
                        <a class="collapse-item" href="<?php echo e(route('suppliers.index')); ?>">
                            <i class="fas fa-fw fa-users"></i>
                            <span>Suppliers</span>
                        </a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#settingsMenu"
                    aria-expanded="false" aria-controls="settingsMenu">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Settings</span>
                </a>
                <div id="settingsMenu" class="collapse">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="<?php echo e(route('customer.index')); ?>">
                            <i class="fas fa-fw fa-user"></i>
                            <span>Data Customer</span>
                        </a>
                        <a class="collapse-item" href="<?php echo e(route('employe.index')); ?>">
                            <i class="fas fa-fw fa-users"></i>
                            <span>Data Employee</span>
                        </a>
                        <a class="collapse-item" href="<?php echo e(route('companies.index')); ?>">
                            <i class="fas fa-fw fa-users"></i>
                            <span>Companies</span>
                        </a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">


            <div class="text-center mb-2">
                <form action="<?php echo e(route('logout', ['id' => 1])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Logout</button>
                </form>
            </div>

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

            <!-- Sidebar Message -->
            <div class="sidebar-card d-none d-lg-flex">
                <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="...">
                <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components,
                    and more!</p>
                <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to
                    Pro!</a>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content" style="padding-top: 20px;">

                <!-- Topbar -->
                
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!-- End of Main Content -->

            </div>
            <!-- End of Content Wrapper -->

        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="login.html">Logout</a>
                    </div>
                </div>
            </div>
        </div>



        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo e(asset('conquer/vendor/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('conquer/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

        <!-- Core plugin JavaScript-->
        <script src="<?php echo e(asset('conquer/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

        <!-- Custom scripts for all pages-->
        <script src="<?php echo e(asset('conquer/js/sb-admin-2.min.js')); ?>"></script>

        <!-- Page level plugins -->
        <script src="<?php echo e(asset('conquer/vendor/chart.js/Chart.min.js')); ?>"></script>

        <!-- Page level custom scripts -->
        <script src="<?php echo e(asset('conquer/js/demo/chart-area-demo.js')); ?>"></script>
        <script src="<?php echo e(asset('conquer/js/demo/chart-pie-demo.js')); ?>"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>


        <?php if(session('success')): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: '<?php echo e(session('success')); ?>',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK'
                    });
                });
            </script>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: '<?php echo e(session('error')); ?>',
                        confirmButtonColor: '#d33',
                        confirmButtonText: 'OK'
                    });
                });
            </script>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    let errorMessages = '';
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        errorMessages += '<p><?php echo e($error); ?></p>';
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    Swal.fire({
                        icon: 'error',
                        title: 'Validation Errors',
                        html: errorMessages,
                        confirmButtonColor: '#d33',
                        confirmButtonText: 'OK'
                    });
                });
            </script>
        <?php endif; ?>


        <!-- Yield for additional scripts -->

</body>

</html>
<?php /**PATH G:\kerja\tajoki\laravel\pos_laravel\CiS\resources\views/layouts/conquer.blade.php ENDPATH**/ ?>