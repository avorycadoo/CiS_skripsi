

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Sales Return Details - Invoice Number: <?php echo e($retur->invoice_number); ?></h2>

        <div class="card shadow-sm">
            <div class="card-body">
                <h5><strong>Customer:</strong> <?php echo e($retur->customer->name); ?></h5>
                <h5><strong>Product:</strong> <?php echo e($retur->product->name); ?></h5>
                <h5><strong>Return Quantity:</strong> <?php echo e($retur->quantity); ?></h5>
                <h5><strong>Refund Amount:</strong> Rp <?php echo e(number_format($retur->refund_amount, 0, ',', '.')); ?></h5>
                <h5><strong>Status:</strong> <span id="status"><?php echo e($retur->status); ?></span></h5>
                <h5><strong>Return Description:</strong> <?php echo e($retur->retur_desc); ?></h5>
                <h5><strong>Created At:</strong> <?php echo e($retur->created_at); ?></h5>
                <h5><strong>Updated At:</strong> <?php echo e($retur->updated_at); ?></h5>

                <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="statusCheckbox"
                        <?php echo e($retur->status == 'Return completed' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="statusCheckbox"
                        style="font-weight: bold; color: #fff; background-color: #28a745; padding: 5px; border-radius: 2px; margin-left: 5px;">
                        Return Completed
                    </label>
                </div>


                <div class="text-center mt-4">
                    <a href="<?php echo e(route('salesRetur.index')); ?>" class="btn btn-info">Back to Returns</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('statusCheckbox').addEventListener('change', function() {
            const isChecked = this.checked;
            const status = isChecked ? 'Return completed' : 'Return initiated';
            const returId = <?php echo e($retur->id); ?>;

            // Send AJAX request to update the status
            fetch(`/retur/${returId}/update-status`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('status').innerText = status; // Update the displayed status
                    } else {
                        alert('Failed to update status.');
                    }
                })
                .catch(error => console.error('Error:', error));
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS_skripsi\CiS\CiS\resources\views/salesRetur/detail.blade.php ENDPATH**/ ?>