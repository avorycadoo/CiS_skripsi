<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Transaction Details - <?php echo e($sale->noNota); ?></h2>

        <div class="card shadow-sm">
            <div class="card-body">
                <h5><strong>Customer:</strong> <?php echo e($sale->customer->name); ?></h5>
                <h5><strong>Total Price:</strong> Rp <?php echo e(number_format($sale->total_price, 0, ',', '.')); ?></h5>
                <h5><strong>Payment Method:</strong> <?php echo e($sale->paymentMethod->name); ?></h5>
                <h5><strong>Date:</strong> <?php echo e($sale->date); ?></h5>
                <h5><strong>Shipped Date:</strong> <?php echo e($sale->shipped_date); ?></h5>
                <h5><strong>Discount:</strong> Rp <?php echo e(number_format($sale->discount, 0, ',', '.')); ?></h5>
                <h5><strong>Shipping Cost:</strong> Rp <?php echo e(number_format($sale->shipping_cost, 0, ',', '.')); ?></h5>
                <h5><strong>Created At:</strong> <?php echo e($sale->created_at); ?></h5>
                <h5><strong>Updated At:</strong> <?php echo e($sale->updated_at); ?></h5>

                <h5 class="mt-4">Products:</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($sale->salesDetail->isNotEmpty()): ?>
                            <?php $__currentLoopData = $sale->salesDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($detail->product->name); ?></td>
                                    <td><?php echo e($detail->total_quantity); ?></td>
                                    <td>Rp <?php echo e(number_format($detail->total_price, 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-center">No products found for this sale.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>

                </table>

                <div class="text-center mt-4">
                    <a href="<?php echo e(route('pos.print', ['id' => $sale->id])); ?>" target="_blank" class="btn btn-primary">Print
                        Receipt</a>
                    <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-info">Back to Transactions</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\kerja\tajoki\laravel\pos_laravel\CiS\resources\views/sales/detail.blade.php ENDPATH**/ ?>