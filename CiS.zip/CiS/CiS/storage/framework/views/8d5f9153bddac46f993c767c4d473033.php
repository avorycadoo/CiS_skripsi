

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center mb-4">Return Information</h2>
                <div class="d-flex justify-content-end mb-3">
                    <a href="<?php echo e(route('salesRetur.create')); ?>" class="btn btn-info"
                        style="background-color: #040404; color: white; border: none; transition: background-color 0.3s;">
                        + New Return
                    </a>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $returs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="card shadow-sm h-100">
                                <div class="card-body">
                                    <h3 class="card-title text-center">Sales Return</h3>
                                    <h5 class="card-title text-center">Invoice Number: <?php echo e($retur->invoice_number); ?></h5>
                                    <p class="card-text text-center">
                                        <strong>Customer Name:</strong> <?php echo e($retur->customer->name); ?>

                                    </p>
                                    <p class="card-text text-center">
                                        <strong>Status:</strong> <?php echo e($retur->status); ?>

                                    </p>
                                    <div class="text-center">
                                        <a class="btn btn-warning btn-sm"
                                            style="background-color: rgb(9, 9, 9); color: white; margin-right: 5px;"
                                            href="<?php echo e(route('salesRetur.detail', $retur->id)); ?>">Detail</a>
                                        <form method="POST" action="<?php echo e(route('salesRetur.destroy', $retur->id)); ?>"
                                            style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="submit" value="Delete" class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you sure to delete return for <?php echo e($retur->invoice_number); ?>?');">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS_skripsi\CiS\CiS\resources\views/salesRetur/index.blade.php ENDPATH**/ ?>