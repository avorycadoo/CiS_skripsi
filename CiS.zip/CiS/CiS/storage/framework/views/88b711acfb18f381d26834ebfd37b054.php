

<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('purchase.updateConfiguration')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <h2 class="text-center mb-4">Shipping Configuration</h2>
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="form-group">
                        <label for="shippings">Select Shippings:</label><br>
                        <?php $__currentLoopData = $shippings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center mb-2">
                                <input class="form-check-input me-2" type="checkbox" name="shippings[]"
                                    value="<?php echo e($shipping->id); ?>" id="shipping<?php echo e($shipping->id); ?>"
                                    <?php echo e($shipping->statusActive === 1 ? 'checked' : ''); ?>

                                    <?php echo e($shipping->types === 'mandatory' ? 'disabled' : ''); ?>>
                                <label class="form-check-label me-2" for="shipping<?php echo e($shipping->id); ?>">
                                    <?php echo e($shipping->name); ?>

                                </label>
                                <input type="number" name="shipping_values[<?php echo e($shipping->id); ?>]" 
                                    class="form-control w-25" value="<?php echo e($shipping->value); ?>">
                            </div>
                            <div>
                                <small class="text-muted"><?php echo e($shipping->desc); ?></small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            
            <h2 class="text-center mb-4">Payment Methods Configuration</h2>
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="form-group">
                        <label for="payments">Select Payment Methods:</label><br>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center mb-2">
                                <input class="form-check-input me-2" type="checkbox" name="payments[]"
                                    value="<?php echo e($payment->id); ?>" id="payment<?php echo e($payment->id); ?>"
                                    <?php echo e($payment->statusActive === 1 ? 'checked' : ''); ?>

                                    <?php echo e($payment->types === 'mandatory' ? 'disabled' : ''); ?>>
                                <label class="form-check-label me-2" for="payment<?php echo e($payment->id); ?>">
                                    <?php echo e($payment->name); ?>

                                </label>
                            </div>
                            <div>
                                <small class="text-muted"><?php echo e($payment->desc); ?></small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            
            <h2 class="text-center mb-4">COGS Method Configuration</h2>
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="form-group">
                        <label for="cogs">Select COGS Method:</label><br>
                        <?php $__currentLoopData = $cogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cogs_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center mb-2">
                                <input class="form-check-input me-2" type="checkbox" name="cogs[]"
                                    value="<?php echo e($cogs_method->id); ?>" id="cogs_method<?php echo e($cogs_method->id); ?>"
                                    <?php echo e($cogs_method->statusActive === 1 ? 'checked' : ''); ?>

                                    <?php echo e($cogs_method->types === 'mandatory' ? 'disabled' : ''); ?>>
                                <label class="form-check-label me-2" for="cogs_method<?php echo e($cogs_method->id); ?>">
                                    <?php echo e($cogs_method->name); ?>

                                </label>
                            </div>
                            <div>
                                <small class="text-muted"><?php echo e($cogs_method->desc); ?></small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Save Configurations</button>
        </form>
        <br><br>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS_skripsi\CiS\CiS\resources\views/purchase/konfigurasi.blade.php ENDPATH**/ ?>