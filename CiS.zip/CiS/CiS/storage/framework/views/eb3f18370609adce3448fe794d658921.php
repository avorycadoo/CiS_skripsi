;
<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class ="alert alert-success"> <?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <a href=<?php echo e(route('categories.create')); ?> class= "btn btn-success" style="background-color: #000000; color: white;"> + Category </a>

    <table class="table">
        <thead>
            <tr>
                <th>Category Name</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="tr_<?php echo e($d->id); ?>">
                    <td><?php echo e($d->name); ?></td>
                    <td><a class="btn btn-warning" href="<?php echo e(route('categories.edit', $d->id)); ?>"
                        style="background-color: #000000; color: white;"> Edit</a>
                        <form method="POST" action="<?php echo e(route('categories.destroy', $d->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="delete" class="btn btn-danger"
                                onclick="return confirm('Are you sure to delete <?php echo e($d->id); ?> - <?php echo e($d->name); ?> ? ');">
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<div class="modal fade" id="modalEditA" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog modal-wide">
        <div class="modal-content">
            <div class="modal-body" id="modalContent">
                
            </div>
        </div>
    </div>
</div>


<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/conquer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\CiS_skripsi\CiS\CiS\resources\views/categories/index.blade.php ENDPATH**/ ?>